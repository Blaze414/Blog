---
title: "Tokyo Skytree and Shibuya: a day above the city lights"
slug: "tokyo-skytree-and-shibuya"
category: "Travel"
date: "2026-07-21"
displayDate: "21 July 2026"
author: "Al Zadid Yusuf"
summary: "From long queues and a sky-high awkward photo to burgers, neon and Hachikō—a day in Tokyo made memorable by all its imperfect moments."
tags:
  - Tokyo
  - Japan travel
  - Tokyo Skytree
  - Shibuya
  - Travel stories
---

# Tokyo Skytree and Shibuya: a day above the city lights

> Travel is rarely remembered as a perfect itinerary. More often, it stays with us as a collection of small surprises, crowded views and stories we did not plan.

## Finding the way up

On the morning of May 17, my brother-in-law and I travelled from Umejima Station to Tokyo Skytree Station, changing trains at Kita-senju along the way. We left at around 11:00 a.m., avoiding the morning rush hour and enjoying a smooth, comfortable journey.

Things became less straightforward after we arrived. We somehow walked in circles while trying to find the entrance and ticket counter. Because we had not booked in advance, a massive queue was waiting for us. While searching, we came across a Taiwanese festival outside the tower—an unexpected burst of colour and energy that made the wait more interesting.

![Colourful lanterns and peaked tents at the Taiwanese festival outside Tokyo Skytree](./images/taiwanese-festival.jpg)

*The Taiwanese festival outside Tokyo Skytree—an unexpected and very welcome detour before the queues.*

After buying our tickets, we found another queue near the entrance. Altogether, we waited for around an hour and a half and finally entered Tokyo Skytree at approximately 3:30 p.m.

![Tokyo Skytree photographed from below outside its entrance against a blue sky](./images/skytree-entrance.jpg)

*Tokyo Skytree from outside the entrance—the sort of view that makes “just look up” feel like incomplete advice.*

## Tokyo from above

Our journey upwards began in an autumn-themed elevator decorated with beautiful seasonal motifs. The interior was impressive, and the lift travelled towards Floor 350 at around 36 kilometres per hour.

When the doors opened, the panoramic view stopped us in our tracks. Tokyo seemed to stretch endlessly in every direction, with Tokyo Tower visible in the distance. Enjoying it also meant carefully navigating crowds of visitors, each searching for the perfect position for a photograph.

![Wide aerial view of Tokyo and the river from the Tokyo Skytree observation deck](./images/skytree-view.jpg)

*Tokyo stretching towards the horizon from the observation deck—a city that seemed to have no visible ending.*

We then continued to Floor 445 and entered the Tembo Galleria. Its gently sloping, glass-walled skywalk circles upwards towards Floor 450. At Sorakara Point, the tower’s highest accessible point, the enormous city below felt almost impossible to comprehend. Despite the crowds, I managed to take plenty of photographs while everyone around me tried to capture the same extraordinary scale.

## The imperfect photo

On Floor 450, I tried the Floating Photo service, which creates the illusion that you are suspended above the Tokyo skyline. I have never felt completely comfortable being photographed—especially when I have to pose—so I became awkward and produced a rather embarrassing result.

Still, it was a once-in-a-lifetime opportunity, and I am glad I did it. Looking back, the awkward pose makes the image more personal. It records not only where I was, but exactly how I felt in that moment.

> Sometimes the imperfect moments become the best memories because they capture how you genuinely felt at the time.

## Back on the ground

Once we had finished exploring, we descended in two stages: from Floor 445 to Floor 350, then from Floor 350 to Floor 5. Throughout the visit, my brother-in-law served as my personal translator because he is fluent in Japanese. I attempted to survive with my extremely limited “yes, no and very good” level of Japanese. I probably embarrassed myself a few times, but that was part of the fun.

From Floor 5, we took the escalators down to Level 2 and stepped outside through the terrace exit near Tokyo Solamachi’s West Yard. After so much time enclosed by lifts, glass and crowds, the open view across the railway tracks and surrounding towers felt like a welcome change of scale.

![Tokyo railway tracks, trains and residential towers viewed from the Level 2 terrace exit](./images/level-two-terrace.jpg)

*The view after stepping out through the Level 2 terrace exit—trains, towers and, finally, a little open space.*

After leaving the tower, we had a late lunch at Kua’Aina Hawaiian Burger & Café. The burgers were genuinely delicious and exactly what we needed after spending so much time waiting, walking and navigating through crowds.

One of the waiters mentioned that she had studied English in Brisbane as part of the mall’s efforts to become more welcoming to international visitors. Since I live in Melbourne, it was amusing and unexpectedly comforting to hear Australia mentioned while visiting Japan.

Unfortunately, despite being handed the perfect conversation starter, I was far too shy to say much—particularly because the waiter was a woman. My brother-in-law eventually stepped in and started the conversation on my behalf, clearly enjoying the opportunity to expose my complete lack of social confidence.

Afterwards, he jokingly asked, “So, did you manage to give her your phone number for future purposes?”

My immediate inner monologue was something along the lines of: *I could barely maintain a normal conversation, and this man expected me to exchange phone numbers? Yes, this is exactly why I am going to remain single.*

Nothing came from the interaction, of course, but it was still a funny and memorable moment. Hearing a reference to Australia in a foreign country felt strangely familiar—even if the encounter also served as another reminder that my social skills still needed considerably more development.

## Shibuya after dark

After lunch, we travelled to Shibuya. Darkness had already fallen, which made it the perfect time to experience the bright screens, neon signs and restless nighttime energy of the famous crossing.

![Shibuya at night with illuminated advertising screens above a dense crowd](./images/shibuya-night.jpg)

*Shibuya after dark: glowing screens, moving crowds and the modern Tokyo I had always imagined.*

We watched crowds move in every direction beneath the enormous illuminated screens. Seeing Shibuya Crossing in person felt completely different from seeing it in films and photographs. The movement, light and surrounding buildings formed the image of modern Tokyo I had always imagined.

We also visited the statue of Hachikō, the loyal Akita remembered for waiting at Shibuya Station for his owner every day, even for years after his owner had died. Too many visitors were waiting for their turn, so I could not take a photo beside the statue. They did, however, make a generous cameo in mine—the closest available compromise. Seeing that symbol of loyalty in person was still meaningful enough.

![The Hachiko statue in Shibuya surrounded by visitors, including a woman and child posing beside it](./images/hachiko-cameo.jpg)

*Hachikō, accompanied by the tourists who prevented my own photo and then secured themselves a surprise cameo. Fair play.*

## Stories worth remembering

After taking in the neon cityscape, we finally headed home. It had been a long day of queues, crowds, breathtaking views, cultural surprises and a few awkward but funny moments.

Despite the waiting, confusion and my embarrassing attempt at the Floating Photo, Tokyo Skytree and Shibuya became one of the most memorable experiences of my trip to Japan. The day reminded me that travel is not only about seeing famous places. It is also about unexpected conversations, small embarrassments and imperfect moments that turn into stories worth telling.
