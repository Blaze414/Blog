# Tokyo Skytree article export

This folder is a framework-independent copy of the article and its original media.

## Contents

- `article.md` — complete article with YAML frontmatter, headings, quotations, image placement, alt text and captions.
- `media-manifest.json` — structured media metadata for importing into another application.
- `images/` — original full-resolution JPEG files. These are the source files, not generated responsive variants.

## Moving it to another blog

1. Copy this entire folder into the other project.
2. Move or import the files from `images/` into that project's media directory.
3. Paste or import `article.md` into the other blog's content system.
4. If the destination changes the image directory, update the six relative `./images/...` paths in `article.md`.
5. Let the destination blog generate its own optimized WebP/AVIF variants from the original JPEGs.

The Markdown keeps the article portable. The JSON manifest preserves dimensions, orientation, alt text and captions if the destination uses structured content.
